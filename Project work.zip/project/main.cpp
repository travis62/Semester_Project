#include <iostream>
#include <string>
#include <vector>

using namespace std; 

class Product {
private:
    string name;
    int quantity;
    double price;

public:
    Product(const string& n, int q, double p) : name(n), quantity(q), price(p) {}

    string getName() const {
        return name;
    }

    int getQuantity() const {
        return quantity;
    }

    double getPrice() const {
        return price;
    }

    void updateQuantity(int newQuantity) {
        quantity = newQuantity;
    }

    void updatePrice(double newPrice) {
        price = newPrice;
    }
};

class Inventory {
private:
    vector<Product> products;

public:
    void addProduct(const Product& product) {
        products.push_back(product);
    }

    Product* findProduct(const string& productName) {
        for (vector<Product>::iterator it = products.begin(); it != products.end(); ++it) {
            if (it->getName() == productName) {
                return &(*it);
            }
        }
        return 0; 
    }

    void displayInventory() const {
        cout << "Inventory:\n";
        for (vector<Product>::const_iterator it = products.begin(); it != products.end(); ++it) {
            const Product& product = *it;
            cout << "Name: " << product.getName() << ", Quantity: " << product.getQuantity() << ", Price: $" << product.getPrice() << "\n";
        }
    }
};

int main() {
    Inventory inventory;
     cout<<" MELCOM GH inventory system"<<endl;
    int numProducts;
    cout << "Enter the number of products to be add: ";
    cin >> numProducts;

    for (int i = 0; i < numProducts; ++i) {
        string name;
        int quantity;
        double price;
        
        
        cout << "Enter product name: ";
        cin >> name;

        cout << "Enter quantity: ";
        cin >> quantity;

        cout << "Enter price: ";
        cin >> price;

        Product product(name, quantity, price);
        inventory.addProduct(product);
    }

    inventory.displayInventory();

    string updateChoice;
    cout << "Do you want to update existing inventory? (yes/no): ";
    cin >> updateChoice;

    if (updateChoice == "yes") {
        string updateProductName;
        cout << "Enter the name of the product to update: ";
        cin >> updateProductName;

        Product* foundProduct = inventory.findProduct(updateProductName);

        if (foundProduct) {
            double newPrice;
            cout << "Enter the new price: ";
            cin >> newPrice;

            foundProduct->updatePrice(newPrice);

            int newQuantity;
            cout << "Enter the new quantity: ";
            cin >> newQuantity;

            foundProduct->updateQuantity(newQuantity);

            cout << "Product updated!\n";
        } else {
            cout << "Product not found.\n";
        }
    }

    inventory.displayInventory();

    return 0;
}
